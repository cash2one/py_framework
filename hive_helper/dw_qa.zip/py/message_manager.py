#!/usr/bin/env python
#!coding:utf8
import requests
import json
import os
import time
import datetime
import logging
from optparse import OptionParser
from HiveUtil import HiveUtil
from template_html import html_tp
from app_conf import MYSQL_CONF, BASEDIR,hrcodes
from dw_qa_util import get_date, DB_CONN

contact = [{'hrCode': hrcode} for hrcode in hrcodes.split(',')]
print contact

def send_msg(contact, title, content):
    apiurl = 'http://adp.data.autohome.com.cn/notice/msgApi/sendMsgApi.json'
    logging.debug('%s,%s' % (title, content))
    # return
    data = {
        #"type" : "ding,mail,sms",
        "type": "mail",
        "title": title,
        "content": title + " " + content,
        "user": contact
    }
    #%(title,data[0],data[2],data[3])
    rq = requests.post(apiurl, data=json.dumps(data))
    jo = rq.json()
    print jo
    print jo['message'].encode('utf8')


def html_table(title, header, rows):
    def tpl(tag, ret=''):
        return '<{0}>{1}%s{1}</{0}>'.format(tag, ret)
    tr = tpl('tr')
    th = tpl('th')
    td = tpl('td')
    tb = tpl('table', '\n')
    # print th,td
    html_title = tpl('h3') % title
    html_header = tr % (''.join([th % el for el in header]))
    html_table = '\n'.join(
        [tr % (''.join([td % el for el in row])) for row in rows])
    # print html_header,html_table
    return html_title + '\n' + tb % ('\n'.join([html_header, html_table]))


def query_data(sql):
    db = DB_CONN(*MYSQL_CONF)
    rows = []
    db.mysql_query_meta(sql)
    col_names = db.field_names
    for row in db.mysql_query(sql):
        rows.append(row)
    return rows, col_names


def send_qa_report(dt):
    html = html_tp % ''
    tbls = open(BASEDIR + '/conf/table_list').read().splitlines()
    date = dt.replace('-', '')
    cmds = ''
    hu = HiveUtil()
    html_tbs = []
    for tb_name in tbls:
        for type in ('field', 'table'):
            tb_name = hu.remove_prefix(tb_name)
            f_sql = """ \
                    select 
                   report_date '日期',dim_value '渠道',
                   -- concat(database_name,'.'   ,table_name,'.',field_name) as `字段`,
                    concat(field_name) as `字段`,
                   concat( rule_type,'  ', rule_sub_type) as '规则类型',
                    rule_id '规则id',    num_valid '合规',num_invalid '非合规'
                from  monitor_field_rule_result_stat 
                where report_date='%s' and table_name='%s' limit 1000""" % (date, tb_name)
            t_sql = """ \
                    select 
                    report_date '日期',
                        concat(database_name,'.'   ,table_name) as `日志表`,
                        rule_type '规则类型',rule_id '规则id',
                    dim_value_1 '维度值1',dim_value_2 '维度值2',index_value '计数',order_num '排名'
                from  monitor_table_rule_result_stat 
                where report_date='%s' and table_name='%s' limit 1000""" % (date, tb_name)
            print f_sql
            print t_sql
            if type == 'field':
                rows, h = query_data(f_sql)
                tb_title = '[字段级合规 %s]' % (tb_name)
            elif type == 'table':
                rows, h = query_data(t_sql)
                tb_title = '[表级合规 %s]' % (tb_name)
            if len(rows) == 0:
                print '[empty:]', date, tb_name
                continue
            html_tbs.append(html_table(tb_title, h, rows))
    html = html_tp % ('<hr/>\n'.join(html_tbs))
    #with open('test.html', 'w') as fh: fh.write(html)
    send_msg(contact, '数据稽核报告 日期 %s' % date, html)


def main():
    parser = OptionParser()
    dft_date = get_date(days=-1)
    parser.add_option("-d", "--date", dest="date",
                      default=dft_date, help='date to import')
    parser.add_option("-s", "--source", dest="source_table",
                      default='_', help='source_table split by ","')
    (opts, args) = parser.parse_args()
    send_qa_report(opts.date)

if __name__ == '__main__':
    main()
