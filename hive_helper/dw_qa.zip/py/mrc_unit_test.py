from trans_mr import MRContext


def test_check_valid(mrc):
    print mrc.check_valid('ip', '127.0.0.1')
    print mrc.check_valid('ip', '10.5.0.1')
    print mrc.check_valid('ip', '120.5.0.0.1')
    print mrc.check_valid('ip', '1.0.0.1')
    print mrc.check_valid('unixtime_s', '1234567899')
    print mrc.check_valid('unixtime_ms', '1234567889999')
    print mrc.check_valid('float', '1234567889999')
    print mrc.check_valid('float', 'a1234567889999')
    print mrc.check_valid('int', 'a1234567889999')


class Obj():
    pass


def main():
    opts = Obj()
    opts.rule = ''
    opts.meta = ''
    mrc = MRContext()
    test_check_valid(mrc)

if __name__ == '__main__':
    main()
