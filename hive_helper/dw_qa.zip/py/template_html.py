html_tp = '''\
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title></title>
    <style type="text/css">
<!--
body,table{
    font-size:15px;
}
table{
    table-layout:fixed;
    empty-cells:show; 
    border-collapse: collapse;
    margin:0 auto;
}
td{
    height:20px;
}
h1,h2,h3{
    font-size:16px;
    margin:0;
    padding:0;
}

h3 { background: #FFF; border: 1px solid #9DB3C5; padding: 1px; width:90%%;margin:20px auto; }
h3 { line-height: 31px; text-align:center;  background: #2F589C url(th_bg2.gif); background-repeat: repeat-x; background-position: 0 0; color: #FFF; }
th, td { border: 1px solid #CAD9EA; padding: 5px; }

table{
    border:1px solid #cad9ea;
    color:#666;
}
table th {
    background-image: url(th_bg1.gif);
    background-repeat::repeat-x;
    height:30px;
}
table td,table th{
    border:1px solid #cad9ea;
    padding:0 1em 0;
}
table tr{
    background-color:#f5fafe;
}

-->
</style>
</head>
<body>
%s
</body>
</html>
'''
