#!coding:utf8
import json
import logging
from pprint import pprint
import os
from optparse import OptionParser
from dw_qa_util import DB_CONN, get_date
from app_conf import app_conf, db_prefix, BASEDIR, MYSQL_CONF
from HiveUtil import HiveUtil
from merge_dims import merge_dims
import re
# TODO dims file merge

def all_equal_one(*ints):
    for it in ints:
        if it !=1:
            return False
    return True

def get_rules_from_db(conn):
    sql = '''
    select 
        concat(b.field_name,'-',b.field_id,'-',ifnull(c.rule_type,''),
            '-',ifnull(c.rule_sub_type,''),'-',c.rule_id) as rule_code,
        
        a.type_id,       a.database_name,
        a.table_name,    a.table_id,a.table_desc,
        a.status as table_status,        b.field_name,
        b.field_id,b.field_type,    b.is_valid as field_is_valid,
        b.status as field_status,   b.importance as importance,
        c.rule_id, c.rule_name,          c.rule_desc,
        c.rule_type,          c.rule_sub_type,
        c.rule_expression_1,  c.rule_expression_2,
        c.is_valid as rule_is_valid,      c.status as rule_status
    from monitor_field_rule_info c 
    left join monitor_field_info b on b.field_id=c.field_id and b.table_id=c.table_id
    left join monitor_table_info a on a.table_id=b.table_id
    '''
    rules_view = []
    conn.mysql_query_meta(sql)
    col_names = conn.field_names
    for row in conn.mysql_query(sql):
        # print '\t'.join(map(str, row))
        rules_view.append(dict(zip(col_names, row)))
    try:
        jo = json.dump(rules_view, open(
            BASEDIR + '/data/rules_cache.json', 'w'), indent=2)
    except:
        logging.error('dump json file fail')
        pass
    return rules_view

PAT_TBNAME = re.compile('^\w+$')
def is_field_name(expr):
    expr = expr.strip()
    m = PAT_TBNAME.match(expr)
    if m:
        return True, expr
    else:
        return False, expr


def getkeys_notvalid(dic, lst):
    rdic = {}
    for k in lst:
        vlu=str(dic.get(k, None))
        if vlu!='1':
            rdic[k] = vlu
    return rdic


def parse_rules_to_json_conf(rules_view):
    # logging.debug( pprint(rules_view))
    parse_result = {}
    rule_types = set()
    for row in rules_view:
        table_name = '{0}.{1}'.format(row['database_name'], row['table_name'])
        parse_result.setdefault(table_name, {})
        tbl_obj = parse_result[table_name]

        rule_types.add(row['rule_type'])
        rule_type = row['rule_type']
        rule_sub_type = row['rule_sub_type']
        rule_code = row['rule_code']
        field_name = row['field_name']
        rule_expression_1 = row['rule_expression_1']
        rule_expression_2 = row['rule_expression_2']
        importance = row['importance']
        #
        tbl_obj['table_name'] = table_name
        tbl_obj['refresh_time'] = get_date(fmt='%Y-%m-%d %H:%M:%S')
        tbl_obj.setdefault('direct_rules', {})
        tbl_obj.setdefault('derive_cols', {})
        tbl_obj.setdefault('table_level_rules', {})
        tbl_obj.setdefault('importance', {})
        tbl_obj.setdefault('dim_files', {})
        try:
            status = all_equal_one(int(row['rule_status']), int(
                row['field_status']), int(row['table_status']))
            is_valid = all_equal_one(int(row['rule_is_valid']),
                           int(row['field_is_valid']))
        except:
            logging.error('RULE DATA ERROR!: %s' % row)

        ##############################################
        ########## rules type router #################
        ##############################################
        ## filter not valid
        if (status != 1) or (is_valid != 1):
            info = 'DeactiveRule: %s,%s' % (rule_code, getkeys_notvalid(
                row, ['rule_status', 'rule_is_valid','field_status', 'field_is_valid','table_status']))
            logging.info(info)
            continue
        # dim type
        elif rule_type in [u'dim']:
            # logging.debug(pprint(row))
            dim_file = '%s.gz' % rule_code
            # hard code for user_id
            if rule_code.startswith('user_id'):
                dim_file = 'user_id.zip.gz'
            # save dim_files info
            if rule_expression_1 is None:
                logging.error('No Query %s;%s',rule_code,rule_expression_1 )
            tbl_obj['dim_files'][dim_file] = {
                'query': rule_expression_1, 'rule_codes': [rule_code]}
            # print dim_file
            # is direct field of table
            if rule_expression_2 is None:
                is_field_flg, expr = True,field_name
            else:
                is_field_flg, expr = is_field_name(rule_expression_2)
            logging.debug('%s; %s' % (expr, is_field_flg))
            # source dim field handle
            if is_field_flg:
                field_name = expr
                tbl_obj['direct_rules'][rule_code] = \
                    {'type': 'dim', 'rule_code': rule_code,
                     'field': field_name,
                     'dim_file': dim_file}
            else:
                # TODO complex dim
                logging.debug('parse dim rule expr : %s' % expr)
                expr = 'concat(%s)' % expr.replace(';', ",'\t',")
                tbl_obj['derive_cols'][rule_code] = expr
                tbl_obj['direct_rules'][rule_code] = \
                    {'type': 'dim', 'rule_code': rule_code,
                     'field': rule_code, 'dim_type': 'complex',
                     'dim_file': dim_file}
        
        # fieldtype check type
        elif rule_type in [u'fieldtype', ]:
            # logging.debug(pprint(row))
            tbl_obj['direct_rules'][rule_code] = \
                {'type': 'field_type', 'rule_code': rule_code,
                 'field': field_name,
                 'field_type': rule_sub_type}

        # zero type
        elif rule_type in [u'zero', ]:
            # logging.debug(pprint(row))
            sql = '''case when {0} not in (0,'0','') then 'valid' 
                else {0} end
            '''
            tbl_obj['derive_cols'][rule_code] = sql.format(field_name)

        # null type
        elif rule_type in [u'null', ]:
            # logging.debug(pprint(row))
            sql = '''case when {0} is not null and {0} not in ('null','','\\n') then 'valid' 
                else {0} end
            '''
            tbl_obj['derive_cols'][rule_code] = sql.format(field_name)

        # enum type
        elif rule_type in [u'enum']:
            # logging.debug(pprint(row))
            sql = '''case when {0} in ({1}) then 'valid' 
                else {0} end
            '''
            tbl_obj['derive_cols'][rule_code] = sql.format(
                field_name, rule_expression_1)

        # custom type
        elif rule_type in [u'length', u'custom', u'reg', u'range']:
            # logging.debug(pprint(row))
            tbl_obj['derive_cols'][rule_code] = rule_expression_1

        # not handle rules
        # table rules pass
        elif rule_type in [u'topn']:
            logging.debug('table level rule_type: %s' % row)
            fields=rule_expression_2
            field_names = fields.replace(' ', '').split(',')
            tbl_lvl_rules = tbl_obj['table_level_rules']
            counttype=rule_expression_1
            tbl_lvl_rules.setdefault(counttype, {})
            tbl_lvl_rules[counttype][rule_code] = {
                'field_names': field_names}
        elif rule_type in [u'dupt']:
            logging.warning('table level rule_type: %s' % row)
        # no rule_type
        elif rule_type is None:
            logging.warning('rule_type is null: %s' % row)
        # other pass
        else:
            logging.error('not support rule_type : %s' % row)
        tbl_obj['importance'].setdefault(importance, [])
        tbl_obj['importance'][importance].append(rule_code)
    # logging.debug(pprint(parse_result) )
    # TODO  Dim file merge
    json.dump(parse_result, open(
        BASEDIR + '/data/rule/all.parsed.json', 'w'), indent=2)
    parse_result = merge_dims(parse_result)
    #json.dump(parse_result, open(BASEDIR + '/data/rule/merged.parsed.json', 'w'), indent=2)
    # TODO  Dim file merge
    return parse_result


def get_db_meta(conn):
    for row in conn.mysql_query('show tables'):
        tb = row[0]
        for row in conn.mysql_query('desc ' + tb):
            print tb, row

def gen_dim_require(dim_files):
    pat=re.compile('from (\w+\.\w+)')
    dep=set()
    for query in [vlu['query'] for key,vlu in dim_files.items()]:
        dep.add( pat.search(query).group(1) )
    return list(dep)

def refresh_dims_files(dim_files, remove_dims=False):
    hu = HiveUtil()
    from IdZipList import convert_to_id_ziplist
    for dfname in dim_files:
        full_dfname = BASEDIR + '/data/dims/' + dfname
        sql = ' '.join(dim_files[dfname]['query'].splitlines())
        if remove_dims or (not os.path.exists(full_dfname)):
            sql = sql.replace('{yyyy-mm-dd}', "'%s'" % (get_date(days=-1)))
            sql = sql.replace('{yyyy-MM-dd}', "'%s'" % (get_date(days=-1)))
            logging.info('[Update dim file]\n#@@@ %s \n#@@@ %s' %
                         (sql, full_dfname))
            # hard code to user compress user_id
            if dfname == 'user_id.zip.gz':
                hu.dump_query_result_to_gz_file(
                    sql, full_dfname.replace('.zip.gz', '.full.gz'))
                convert_to_id_ziplist(
                    '../data/dims/user_id.full.gz', '../data/dims/user_id.zip.gz')
            else:
                print sql, full_dfname
                hu.dump_query_result_to_gz_file(sql, full_dfname)


def main():
    ##
    parser = OptionParser()
    parser.add_option("-d", "--dims", dest="dims",
                      action="store_true", default=False, help='is refresh dims')
    parser.add_option("-q", "--queryupdate", dest="queryupdate",
                      action="store_true", default=False, help='call query manager')
    parser.add_option("-r", "--remove_dims", dest="remove_dims",
                      action="store_true", default=False, help='is remove dims first')
    parser.add_option("-c", "--cache", dest="from_cache",
                      action="store_true", default=False, help='not refresh from mysql')
    parser.add_option("-t", "--tables", dest="tables",
                      action="store", default=False, help='specify rule update table,split by ","')
    (opts, args) = parser.parse_args()
    print opts
    if not opts.from_cache:
        conn = DB_CONN(*MYSQL_CONF)
        # dump rules to json cache
        get_rules_from_db(conn)
    # get_db_meta(conn)
    # gen table_list
    cache = json.load(open(BASEDIR + '/data/rules_cache.json'))
    tables_json_conf = parse_rules_to_json_conf(cache)
    fname = BASEDIR + '/conf/table_list'
    fh = open(fname, 'w')
    for tbname in tables_json_conf:
        logging.debug('add to table_list: ' + tbname)
        fh.write(tbname + '\n')
    dim_files_to_update = {}
    # make rule file
    if opts.tables:
        table_white_list = opts.tables.split(",")
    for tbname in tables_json_conf:
        if opts.tables and tbname not in table_white_list:
            continue
        single_table_data = tables_json_conf[tbname]
        logging.debug(json.dumps(single_table_data, indent=2))
        fname = BASEDIR + '/data/rule/%s.rule.json' % tbname
        logging.info('[Table: %s,directRule: %s, dimFiles: %s]:\n    %s',
            tbname , len(single_table_data['direct_rules']),
            len(single_table_data['dim_files']),fname)
        with open(fname, 'w') as fh:
            json.dump(single_table_data, fh, indent=2)
        # make dim update list
        dim_files_to_update.update(single_table_data['dim_files'])
    ## dump dim depend file
    dep_tbls = gen_dim_require(dim_files_to_update)
    dim_fnames = dim_files_to_update.keys()
    with open(BASEDIR+'/data/dim_table.json','w') as fh:
        dep_dims = {'tables':dep_tbls,'files':dim_fnames}
        json.dump(dep_dims,fh,indent = 2)
    if opts.dims:
        logging.info( pprint(dim_files_to_update))
        refresh_dims_files(dim_files_to_update, remove_dims=opts.remove_dims)
    if opts.queryupdate:
        import query_manager
        query_manager.main()


if __name__ == '__main__':
    main()
