#!coding:utf8
import json
import sys
import os
import logging

from HiveUtil import HiveUtil

from app_conf import app_conf, db_prefix, BASEDIR


def refresh_tables_meta(tblnames):
    '''
    input a table name(with or with out ods./mds./ads.) list
    get tables column/partition info save json file
    '''
    hu = HiveUtil()
    infos = hu.get_desc_tables(tblnames)
    for tblname, info in infos.items():
        with open(BASEDIR + '/data/meta/%s.meta.json' %
                  hu.add_prefix(tblname), 'w') as fh:
            info['table_name'] = tblname
            json.dump(info, fh, indent=2)
    return infos


def generate_detail_create_table(tblname):
    '''
    generate the hql for create dw_qa table 
    '''
    from template_ddl import create_full_tp
    hu = HiveUtil()
    info = json.load(open(BASEDIR + '/data/meta/%s.meta.json' %
                          hu.add_prefix(tblname)))
    tbl_conf = app_conf['projects']['error']
    prj_dir = tbl_conf['proj_dir']
    suffix = tbl_conf['suffix']
    o_tblname = '%s.%s_%s' % (db_prefix, tblname, suffix)
    short_tblname = '%s_%s' % (tblname, suffix)
    # print info
    fix_head_cols = tbl_conf['info_col']
    fix_part_cols = tbl_conf['part_col']
    col_st = ''
    row_template = " ,{0}    {1}  comment '{2}'\n"
    for row in fix_head_cols:
        field_name = '`%s`' % row[0]
        st = row_template.format(field_name.ljust(
            25), row[1], row[2].encode('utf8'))
        col_st += st
    for row in info['column_info']:
        field_name = '`%s`' % row['col_name']
        st = row_template.format(field_name.ljust(
            25), row['type'].replace("map<string,string>", 'string'), row['comment'].encode('utf8'))
        col_st += st
    par_st = ''
    for row in info['partition_info'][:1]:
        field_name = '`%s`' % row['col_name']
        st = row_template.format(field_name.ljust(
            25), row['type'], row.get('comment', '').encode('utf8'))
        par_st += st
    for row in fix_part_cols:
        st = row_template.format(row[0].ljust(
            25), row[1], row[2].encode('utf8'))
        par_st += st
    col_st = '  ' + col_st.strip(' ,')
    par_st = '  ' + par_st.strip(' ,')
    c_hql = create_full_tp.format(
        short_tblname, col_st, 'dw_qa ods layer for %s' % short_tblname, par_st, layer=db_prefix, project=prj_dir)
    logging.debug(c_hql)
    path = BASEDIR + '/create_table/%s/' % prj_dir
    if not os.path.exists(path):
        os.mkdir(path)
    fname = path + 'create_%s.hql' % (o_tblname)
    with  open(fname, 'w') as fh:
        fh.write(c_hql)
    return fname, c_hql


def generate_stat_create_table(tblname, tbl_type='field'):
    from template_ddl import create_f_stat_tp, create_t_stat_tp
    tbl_conf = app_conf['projects'][tbl_type]
    prj_dir = tbl_conf['proj_dir']
    suffix = tbl_conf['suffix']
    o_tblname = '%s.%s_%s' % (db_prefix, tblname, suffix)
    short_tblname = '%s_%s' % (tblname, suffix)
    if tbl_type .endswith('field'):
        c_hql = create_f_stat_tp.format(
            short_tblname, '', '%s' % short_tblname, '', layer=db_prefix, project=prj_dir)
    elif tbl_type == 'table':
        c_hql = create_t_stat_tp.format(
            short_tblname, '', '%s' % short_tblname, '', layer=db_prefix, project=prj_dir)
    logging.debug(c_hql)
    path = BASEDIR + '/create_table/%s/' % prj_dir
    if not os.path.exists(path):
        os.mkdir(path)
    fname = path + 'create_%s.hql' % (o_tblname)
    with open(fname, 'w') as fh:
        fh.write(c_hql)
    return fname, c_hql


def refresh_all_table():
    '''
    loop all table to process
    '''
    tbls = open(BASEDIR + '/conf/table_list').read().splitlines()
    logging.debug(tbls)
    # update meta json
    refresh_tables_meta(tbls)
    # gen create hql
    fns = []
    hu = HiveUtil()
    for tbl in tbls[0:]:
        tbl = hu.remove_prefix(tbl)
        fn1, hql = generate_detail_create_table(tbl)
        fn2, hql = generate_stat_create_table(tbl, 'field')
        fn3, hql = generate_stat_create_table(tbl, 'table')
        fn4, hql = generate_stat_create_table(tbl, 'important_field')
        #fns += [fn1, fn2, fn3]
        fns += [fn4]
    return fns

if __name__ == '__main__':
    logging.debug(BASEDIR)
    fns = refresh_all_table()
    cmd = ''
    for fn in fns:
        cmd += 'hive -f %s\n' % fn
    with open(BASEDIR + '/sh/auto/create_table.sh', 'w') as fh:
        fh.write(cmd)
