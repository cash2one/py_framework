import gzip
import logging


def convert_to_id_ziplist(fname, foname):
    start_id = None
    end_id = None
    last_id = None
    fh = gzip.open(foname, 'w')
    dic = {}
    for l in gzip.open(fname):
        id = int(l.strip())
        # print id
        if start_id == None:
            start_id = id
        if last_id == None:
            last_id = id
        if id - last_id == 1:
            pass
        else:
            if last_id != None:
                end_id = last_id
            else:
                end_id = id
            dic[start_id] = end_id
            start_id = id
        last_id = id
    dic[start_id] = end_id
    for k in sorted(dic):
        fh.write('%s,%s\n' % (k, dic[k]))


class IdZipList:

    def __init__(self, fname):
        # logging.basicConfig(level=logging.DEBUG)
        self.ziplist = []
        for l in gzip.open(fname):
            start, end = l.strip().split(',', 1)
            start = int(start)
            end = int(end)
            self.ziplist.append((start, end))
        self.zlen = len(self.ziplist)
        logging.debug('load %s ziplist' % self.zlen)

    def is_id_in(self, userid):
        userid = int(userid)
        res = self.bin_search(self.ziplist, userid)
        return res[0]

    def bin_search(self, array, match):
        low = 0
        high = self.zlen - 1
        while low <= high:
            mid = (low + high) / 2
            midval = array[mid]
            logging.info('%s,%s,%s,%s' % (low, mid, high, midval))
            if midval[1] < match:
                low = mid + 1
            elif midval[0] > match:
                high = mid - 1
            else:
                return True, midval
        return False, midval

def test(uidzip):
    print uidzip.is_id_in(35513842)
    print uidzip.is_id_in(3336107)
    print uidzip.is_id_in(100003)
    print uidzip.is_id_in(1000)
    print uidzip.is_id_in(0)

if __name__ == '__main__':
    # convert_to_id_ziplist('../data/dims/user_id-26-dim--34.gz','../data/dims/user_id.zip.gz')
    import sys
    logging.basicConfig(level=logging.DEBUG)
    from optparse import OptionParser
    parser=OptionParser()
    parser.add_option('-i',dest="ids")
    parser.add_option('-f',dest="zipf",default='../data/dims/user_id.zip.gz')
    opts,args = parser.parse_args()
    
    uidzip = IdZipList(opts.zipf)
    logging.debug('zip len %s' % (uidzip.zlen))
    for id in opts.ids.split(","):
        logging.warning('[Id: %s, In_userid: %s]', id,uidzip.is_id_in(id))
