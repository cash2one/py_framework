#!coding:utf8
# python syntax template


hql_prepare_tp = '''\
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles=true;
set hive.exec.parallel=true;
set hive.auto.convert.join=false;
set hive.map.aggr=true;
set mapreduce.job.queuename=root.q_dtb.q_dw.q_dw_qa;

{extra_set}

{trans_add_files}
{add_archives}

'''
hql_error_transform_tp = '''\
-- explain
FROM (
  FROM 
    {source_table}
  MAP 
    {input_cols}
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\\007'
  USING 
    '{map_cmd}'
  AS 
    {map_output_cols}
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\\007'
  {where_condition}
  {map_output_keys}
) map_output
INSERT OVERWRITE TABLE {target_table} PARTITION ({target_partition})
REDUCE * 
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\\007'
USING 
    '{reduce_cmd}'
AS 
    {reduce_output_cols}
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\\007'
;
'''

hql_test_tp = '''\
-- explain
  FROM 
    {source_table}
  SELECT 
    {input_cols}
  {where_condition}
   LIMIT 10000
;
'''

mapper_test_tp = '''\
select TRANSFORM({input_cols}) 
using '{map_cmd}'
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\\001'
  COLLECTION ITEMS TERMINATED BY '\\002'
  MAP KEYS TERMINATED BY '\\003'
from  {source_table}
{where_condition}
limit 10;
'''

reducer_test_tp = '''\
'''


hql_stat_tp = '''
set mapreduce.job.queuename=root.q_dtb.q_dw.q_dw_qa;
{stat_add_files}
{add_archives}


INSERT OVERWRITE TABLE {target_table} PARTITION(dt='${{hivevar:dt}}')
select dimtype,dimvalue,dim_value,sum(cnt)
from (
  select 
  transform(invalid_rule_tag,{other_cols})
    -- using 'pypy5.6.tar.gz/bin/pypy stat_mr.py'
    using '{stat_map_cmd}'
  as dimtype,dimvalue,dim_value,cnt
  from {source_table}
   where dt='${{hivevar:dt}}'
) base_t
group by dimtype,dimvalue,dim_value
;
'''


hql_rank_tp_prep = '''\
set mapreduce.job.queuename=root.q_dtb.q_dw.q_dw_qa;
-- set hive.execution.engine=tez;

'''
hql_rank_tp_cnt = '''\
INSERT OVERWRITE TABLE {target_table} PARTITION(dt='${{hivevar:dt}}', count_type='{count_type}')
-- explain
SELECT groupkey,dimvlu,cnt,rank
FROM 
(
    SELECT groupkey,dimvlu,cnt,
        row_number() over (partition by groupkey order by cnt desc) AS rank
    FROM 
    (
        SELECT groupkey,dimvlu, {count_type} as cnt
        FROM (
            SELECT explode(map({group_dim_pair})) as (groupkey,dimvlu)
            FROM {source_table}
            WHERE dt='${{hivevar:dt}}'
        ) base_t 
        GROUP BY groupkey,dimvlu
    ) base_tt 
) base_ttt WHERE rank <={rankmax};
'''

shell_tp = '''\
#!/bin/sh
# Author: {user}                 #
# Date: {date}                   #
# Describe:{tbname}              #
source ~/.bash_profile
##装载config文件
.  /data/sysdir/dw_qa_server/sh/lib/check_result.sh

etl_date=$(date -d "1 days ago" +%Y-%m-%d)
etl_date=${{1:-$etl_date}}
echo ${{etl_date}}
contact=13681300984
## depend check
hive_check_hour {tbname} 120 120 $etl_date 24 total

{cmd}
check_result $? $(basename $0) $contact
'''


cmd_tp = '''\
##{tbname}
(
  hive -hivevar dt=${{etl_date}}  -f {fname_base} &&       
  check_result $? {tbname}_base $contact && 
  hive -hivevar dt=${{etl_date}}  -f {fname_stat} &&
  check_result $? {tbname}_stat $contact  
) &
hive -hivevar dt=${{etl_date}}  -f {fname_tlr} &
check_result $? {tbname}_tlr $contact 
wait
cd {basedir}/py
python load_result_manager.py -f -d ${{etl_date}} -s {tbname}
check_result $? {tbname}_to_mysql $contact 
'''


local_test_sh_tp = '''\

etl_date=$(date -d "1 days ago" +%Y-%m-%d)
etl_date=${{1:-$etl_date}}
cd {basedir}/py

select_out={basedir}/test/ods/{source_table}.dump.log
map_out={basedir}/test/map/{source_table}.map.out
reduce_out={basedir}/test/reduce/{source_table}.reduce.out

<<TEST
TEST
echo '###  INPUT  ###'
hive -hivevar dt=${{etl_date}} -f {basedir}/hql/test/{source_table}.error.test.hql > $select_out
sed -i 's/\t/\007/g'  $select_out
head $select_out
echo '###  MAP  ###'
head -{head_count} $select_out |  ../{map_cmd} >$map_out
head $map_out
echo '###  REDUCE  ###'
cat $map_out| ../{reduce_cmd} > $reduce_out
head $reduce_out
'''
