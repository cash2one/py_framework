#!coding:utf8
import sys
import re
import os
import json
import gzip
import logging
import datetime
import traceback
from optparse import OptionParser

from os.path import dirname, realpath, basename, splitext
BASEDIR = dirname(dirname(realpath(sys.argv[0])))
stderr = sys.stderr

NUMPAT=re.compile('^\d*\.?\d*$')

def str2int(value):
    if NUMPAT.match(value):
        try:
            value=str(int(float(value)))
        except:
            pass
    return value

def dic2str(dic, arrsep='\002', kvsep='\003'):
    ''' dict 2 string
    '''
    # return json.dumps(dic)
    arr = [''.join([str(k), kvsep, str(v)]) for k, v in dic.items()]
    return arrsep.join(arr)


def str2dic(st, arrsep='\002', kvsep='\003'):
    ''' string 2 dict
    '''
    r_dic = {}
    for kv in st.split(arrsep):
        res = kv.split(kvsep, 1)
        if len(res) > 1:
            k, v = res
        else:
            k, v = res[0], ''
        r_dic[k] = v
    return r_dic

def hdp_cnt(c, g='custom_counterp', a=1):
    '''
    hadoop mr counter
    '''
    st = 'reporter:counter:{0},{1},{2}'.format(g, c, a)
    print >> stderr, st


class IdZipList:

    def __init__(self, fname):
        self.ziplist = []
        for l in gzip.open(fname):
            start, end = l.strip().split(',', 1)
            start = int(start)
            end = int(end)
            self.ziplist.append((start, end))
        self.zlen = len(self.ziplist)
        logging.debug('load %s ziplist' % self.zlen)

    def is_id_in(self, userid):
        userid = int(userid)
        res = self.bin_search(self.ziplist, userid)
        return res[0]

    def bin_search(self, array, match):
        low = 0
        high = self.zlen - 1
        while low <= high:
            mid = (low + high) / 2
            midval = array[mid]
            #logging.debug('%s,%s,%s,%s' % (low, mid, high, midval))
            if midval[1] < match:
                low = mid + 1
            elif midval[0] > match:
                high = mid - 1
            else:
                return True, midval
        return False, midval


class MRContext:
    ''' context class for the transform job
    '''

    def ip2int(self, x):
        return sum([256**j * int(i) for j, i in enumerate(x.split('.')[::-1])])

    def __init__(self):
        self.ishadoop = os.environ.get("mapreduce_job_id", False)
        self.counter = {}

    def load_opts(self, opts, load_dims=True):
        if not self.ishadoop:
            logging.basicConfig(level=logging.DEBUG, stream=stderr)
        else:
            logging.basicConfig(level=logging.ERROR, stream=stderr)
        self.rule = self.load_json(opts.rule)
        self.meta = self.load_json(opts.meta)
        # logging.debug('[[meta]]:\n'+json.dumps(self.meta,indent=2))
        # logging.debug('[[rule]]:\n'+json.dumps(self.rule,indent=2))
        if load_dims:
            self.dims = self.load_dims(opts.dims.split(','))
            logging.debug('Dim keys:%s',self.dims.keys())
        if not self.rule:
            print 'rule file not set'
            raise Exception('NoRuleFile')
        if not self.meta:
            print 'meta file not set'
            raise Exception('NoMetaFile')
        # map input basic columns
        self.mi_basecols = [col_info['col_name'] for col_info in self.meta['column_info']]
        self.mi_partcols = ['dt', 'hour']
        # rule derive columns
        self.mi_rulecols = sorted(self.rule['derive_cols'].keys())
        # map input all columns
        self.mi_allcols = self.mi_basecols + self.mi_partcols + self.mi_rulecols
        # all column cnt
        self.mi_colnum = len(self.mi_allcols)
        # base column cnt
        self.mi_base_colnum = len(self.mi_basecols + self.mi_partcols)
        self.ro_base_colnum = len(self.mi_basecols) - 1
        if not self.ishadoop:
            tbname=self.rule['table_name']
            try:json.dump(self.mi_allcols,open(BASEDIR+'/test/meta.%s.json'%tbname,'w'))
            except:logging.error( 'dump meta fail')

    def row2dict(self, row):
        '''return a dict of data row
        '''
        return dict(zip(self.mi_allcols, row))

    def get_data_channel(self, record):
        if record.has_key('app_key'):
            return record['app_key']
        else:
            return 'total'

    def check_valid(self, field_type, value):
        ''' check is valid
        '''
        if field_type in ('float'):
            try:
                float(value)
                if value.find('NaN') != -1 \
                        or value.find('iNF') != -1 \
                        or value.find('x') != -1:
                    return False, 'python not float string'
                return True, 'float'
            except:
                return False, 'float except'
        elif field_type in ('int'):
            try:
                int(value)
                return True, 'int'
            except:
                return False, 'int except'
        elif field_type in ('unixtime_ms', 'unixtime_s'):
            for tstype, scale in (('unixtime_s', 1), ('unixtime_ms', 1000)):
                try:
                    ts = datetime.datetime.fromtimestamp(
                        int(value) * 1.0 / scale).strftime('%Y-%m-%d')
                    if ts.startswith('20') and field_type == tstype:
                        return True, '%s %s' % (tstype, ts)
                except:
                    # traceback.print_exc()
                    if field_type == tstype:
                        return False, '%s except' % tstype
            return False, 'ts not pass' + ts
        elif field_type in ('ip'):
            try:
                if len(value.split('.')) != 4:
                    return False, 'ip not 4 seg'
                int_ip = self.ip2int(value)
                # Loopback IP
                if value.startswith('127.'):
                    return False, 'ip loopback'
                # LAN IP
                if int_ip >= 167772160L and int_ip <= 184549375L:
                    return False, 'ip local A'
                if int_ip >= 2886729728L and int_ip <= 2887778303L:
                    return False, 'ip local B'
                if int_ip >= 3232235520L and int_ip <= 3232301055L:
                    return False, 'ip local C'
                return True, 'ip'
            except:
                print traceback.print_exc()
                return False, 'ip2int except'
        else:
            return False, 'not support field_type fail'

    def apply_rule(self, record):
        '''apply rule to record
        '''
        r_tag = {}
        # all direct column rule
        for rule_code in self.rule['direct_rules']:
            #logging.debug('Apply rule %s',rule_code)
            rule = self.rule['direct_rules'][rule_code]
            field_name = rule['field']
            if rule.get('dim_type', '') == 'complex':
                value = record[rule_code]
            else:
                value = record[field_name]
            rule_type = rule['type']
            value=str2int(value)
            if rule_type == 'dim':
                if rule_code.startswith('user_id'):
                    try:
                        value = int(value)
                        if not self.user_id_zl.is_id_in(value):
                            r_tag[rule_code] = value
                    except:
                        r_tag[rule_code] = value
                else:
                    #logging.debug('dim value %s',value)
                    if value not in self.dims[rule_code]:
                        r_tag[rule_code] = value  # TODO
            elif rule_type == 'field_type':
                field_type = rule['field_type']
                res = self.check_valid(field_type, value)
                if not res[0]:
                    r_tag[rule_code] = value  # TODO
        # all case when
        for rule_code in self.rule['derive_cols']:
            if rule_code not in self.rule['direct_rules']\
                    and record[rule_code] != 'valid':
                r_tag[rule_code] = record[rule_code]
        return r_tag

    def add_cnt(self, key, count):
        self.counter.setdefault(key, 0)
        self.counter[key] += count

    def load_dim_file(self, fname, key_func=None, fieldnum=None, delimiter='\t'):
        logging.debug('loading %s' % fname)
        r_dic = set()
        if fname.endswith('user_id.zip.gz'):
            self.user_id_zl = IdZipList(fname)
            return
        size = os.stat(fname).st_size
        if size > 10000000:
            logging.debug('Error too big file: %s' % fname)
            return r_dic
        fh = open(fname)
        if fname.endswith('.gz'):
            fh = gzip.open(fname)
        for line in fh:
            row = line.strip().split(delimiter)
            if fieldnum and len(row) < fieldnum:
                logging.debug('Fail to process row: %s' % fname)
                continue
            if key_func:
                key = key_func(row)
            else:
                key = '\t'.join(row)
            r_dic.add(key)
        logging.debug('File : %s; Length %s' % (fname, len(r_dic)))
        return r_dic

    def load_json(self, fname):
        if fname.endswith('must_set.json'):
            return None
        if not self.ishadoop:
            type = fname.split('.')[-2]
            fname = BASEDIR + '/data/%s/' % type + fname
        return json.load(open(fname))

    def load_dims(self, dims_name):
        fdims = {}
        if len(dims_name) == 1 and dims_name[0] == '__empty__':
            pass
        else:
            for fname in dims_name:
                # TODO modify to read self.direct_rule
                rule_codes = self.rule['dim_files'][fname]['rule_codes']
                # for debug
                if not self.ishadoop:
                    file_dic = self.load_dim_file(
                        BASEDIR + '/data/dims/' + fname)
                else:
                    file_dic = self.load_dim_file(fname)
                for rule_code in rule_codes:
                    fdims[rule_code] = file_dic
                    logging.debug("Put %s to fdims's key %s" %
                                  (fname, rule_code))
        return fdims


def cat(opts):
    for line in sys.stdin:
        print line,


def ods_mapper(opts):
    '''mapper for error table
    '''
    F_DEL = '\007'  # field delimiter
    mrc = MRContext()
    mrc.load_opts(opts)
    for line in sys.stdin:
        tag_d = {}  # invalid data tag
        line = line.strip('\n')
        row = line.split(F_DEL)
        if len(row) < mrc.mi_colnum:
            err = 'qa:short_col_num'
            tag_d[err] = len(row)
            hdp_cnt(err)
            print F_DEL.join([dic2str(tag_d), line])
            continue
        record = mrc.row2dict(row)
        #logging.debug( rowd )
        b_idx = mrc.mi_base_colnum
        hour = row[b_idx - 1]
        # derived column
        tag_d.update(mrc.apply_rule(record))
        if len(tag_d) > 0:
            tag_d['qa:hour'] = hour
            output_row = [record[field_name] for field_name in mrc.mi_basecols]
            line = F_DEL.join(output_row)
            print F_DEL.join([dic2str(tag_d), line])
        else:
            data_channel = mrc.get_data_channel(record)
            mrc.add_cnt(data_channel, 1)
    for k, v in mrc.counter.items():
        hdp_cnt(k, a=v)
        print F_DEL.join(['data_sum', k, str(v)])


def ods_reducer(opts):
    F_DEL = '\007'  # field delimiter
    mrc = MRContext()
    mrc.load_opts(opts, load_dims=False)
    for line in sys.stdin:
        row = line.strip().split(F_DEL)
        if row[0] == 'data_sum':
            data_channel = row[1]
            count = int(row[2])
            mrc.add_cnt(data_channel, count)
        else:
            print line.strip('\n')
    cnt = mrc.counter
    cnt['tag_type'] = 'datasum'
    print dic2str(cnt)


if __name__ == '__main__':
    argv = sys.argv
    parser = OptionParser()
    parser.add_option("-j", "--job", dest="job", default='ods_mapper',
                      help="job method name to run", metavar="FILE")
    # for mr context
    parser.add_option("-r", "--rule", dest="rule", default='rule_must_set.json',
                      help="rule info json file", metavar="FILE")
    parser.add_option("-m", "--meta", dest="meta", default='meta_must_set.json',
                      help="meta info json file", metavar="FILE")
    parser.add_option("-d", "--dims", dest="dims", default='__empty__',
                      help="dimension file names split by \",\"", metavar="FILE")
    (opts, args) = parser.parse_args()
    eval(opts.job + '(opts)')
