import sys
import logging
from os.path import dirname, realpath
BASEDIR = dirname(dirname(realpath(sys.argv[0])))
MYSQL_CONF = ('dp-mw0-3306-db.lq.autohome.com.cn',
              'zhineng', 'kisWSlsoe392wsli', 'dw_qa')
META_MYSQL_CONF = ('192.168.201.54','hive','hive','azkaban3')
# logging.basicConfig(filename='../dw_qa_server.log',level=logging.DEBUG)
logging.basicConfig(level=logging.INFO)

hrcodes='6330,5973,7014,8794'

app_conf = {
    #'db_prefix':'dw_tmp',
    'db_prefix': 'qa',
    'projects': {
        'error': {'proj_dir': 'dtl', 'suffix': 'e',
                  'info_col': [
                      ['invalid_rule_tag', 'string', ''],
                  ],
                  'part_col': [
                      # ['dw_qa_type', 'string', 'detail/sum'],
                  ]
                  },
        'field': {
            'proj_dir': 'rst', 'suffix': 'f',
        },
        'important_field': {
            'proj_dir': 'rst', 'suffix': 'f_i',
        },
        'table': {
            'proj_dir': 'rst', 'suffix': 't',
        },
    },
    '': ''
}
db_prefix = app_conf['db_prefix']


if __name__ == '__main__':
    print app_conf
