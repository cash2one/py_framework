#!coding:utf8
import json
import os
import logging
import gzip
from pprint import pprint
from HiveUtil import HiveUtil
from dw_qa_util import get_date, DB_CONN
from optparse import OptionParser

from os.path import basename
from app_conf import app_conf, db_prefix, BASEDIR, MYSQL_CONF

logging.basicConfig(level=logging.DEBUG )

def p_int(st):
    return int(float(st))


def get_field_from_rulecode(rulecode):
    return rulecode.split('-')[0]


def p_int(st):
    return int(float(st))


def load_json_cache(fname, key_cols, ret_cols):
    jo = json.load(open(fname))
    res_dic = {}
    for record in jo:
        keys = [record[col] for col in key_cols.split(',')]
        key = '|'.join(map(str, keys))
        row = [record[col] for col in ret_cols.split(',')]
        res_dic[key] = row
    return res_dic


def parse_field_stat(gz_fname):
    f_cnt = {}
    for line in gzip.open(gz_fname):
        row = line.strip().split('\t')
        dim_type = row[0]
        rule_code = row[1]
        app_key = row[2]
        cnt = row[3]
        dt = dt2int(row[4])
        default_content = {'valid': 0, 'total_invalid': 0,
             'rule_code': {}, 'field': {},
             'importance': {}, 'dim_type': {}}
        if dim_type == 'valid':
            app_key = rule_code
        if app_key =='total':
            app_key=''
            rule_code=''
        # init struct for stat
        f_cnt.setdefault(app_key, default_content)
        if dim_type == 'valid':
            f_cnt[app_key]['valid'] = p_int(cnt)
        elif dim_type == 'rule':
            if rule_code == 'qa:hour':
                f_cnt[app_key]['total_invalid'] = p_int(cnt)
            else:
                f_cnt[app_key]['rule_code'][rule_code] = p_int(cnt)
        elif dim_type == 'field' and rule_code != 'qa:hour':
            field = rule_code
            f_cnt[app_key]['field'][field] = p_int(cnt)
        elif dim_type == 'field' and rule_code == 'qa:hour':
            continue
        elif dim_type == 'importance':
            f_cnt[app_key]['importance'][rule_code] = p_int(cnt)
        elif dim_type == 'dim':
            f_cnt[app_key]['dim_type'][rule_code] = p_int(cnt)
        else:
            logging.info( '[not support row]:%s' % row)
            pass
    #logging.debug(pprint(f_cnt))
    return f_cnt


def load_field_stat(rdic, fdic, dt, fname, tb_name):
    f_sql = '''replace into monitor_field_rule_result_stat
    (report_date,database_name,table_name,field_name,field_id,
    rule_type,rule_sub_type,rule_id,dim_value,num_valid,num_invalid)
     values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);'''
    rows = []
    f_cnt = parse_field_stat(fname)
    dt=dt2int(dt)
    for app_key in f_cnt:
        ak_obj = f_cnt[app_key]
        for rule_code in ak_obj['rule_code']:
            invalid_total = ak_obj['total_invalid']
            valid_total = ak_obj['valid']
            total = invalid_total + valid_total
            invalid_cnt = ak_obj['rule_code'][rule_code]
            new_row = [dt]
            if rule_code not in rdic:
                logging.warning('[Not found exinfo] appkey:%s, rule_code:%s, ' ,app_key, rule_code)
                logging.warning(' appkeyobj:%s' ,ak_obj)
                continue
            new_row.extend(rdic[rule_code])
            new_row.extend(
                [app_key, total - invalid_cnt, invalid_cnt])
            #logging.debug( new_row)
            rows.append(new_row)
        for field in ak_obj['field']:
            tb_name = tb_name.replace('.', '|')
            key = '|'.join([tb_name, field])
            if key is None or key not in fdic:
                continue
            invalid_total = ak_obj['total_invalid']
            valid_total = ak_obj['valid']
            total = invalid_total + valid_total
            invalid_cnt = ak_obj['field'][field]
            new_row = [dt]
            new_row.extend(fdic[key][:-3])
            new_row.extend([-9, -9, -9])
            new_row.extend(
                [app_key, total - invalid_cnt, invalid_cnt])
            # logging.debug( new_row)
            rows.append(new_row)
    return f_sql, rows


def load_f_overview_stat(rdic, dt, fname, tb_name):
    '''overview table'''
    f_sql = '''replace into  monitor_table_record_stat_overview 
    (report_date,database_name,table_id,table_name,dim_value,total_num,invalid_num)
     values(%s,%s,%s,%s,%s,%s,%s);'''
    f_cnt = parse_field_stat(fname)
    rows = []
    # logging.debug( '%s %s'%(rdic.keys(),invalid_sum.keys()))
    for app_key in f_cnt:
        ak_obj = f_cnt[app_key]
        tb_name = tb_name.replace('.', '|')
        key = '|'.join([tb_name])
        # logging.debug( key)
        invalid_total = ak_obj['total_invalid']
        valid_total = ak_obj['valid']
        total = invalid_total + valid_total
        if key not in rdic:
            logging.debug( 'load_f_overview %s %s'% (app_key, key))
            continue
        new_row = [dt2int(dt)]
        new_row.extend(rdic[key])
        new_row.extend(
            [app_key, total, invalid_total])
        rows.append(new_row)
    return f_sql, rows


def load_table_stat(rdic, dt, fname):
    f_sql = '''replace into monitor_table_rule_result_stat
    (report_date,database_name,table_name,table_id,rule_type,rule_id,dim_value_1,dim_value_2,index_value,order_num)
     values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);'''
    rows = []
    KVSEP='\005'
    for line in gzip.open(fname):
        r = line.strip().split('\t')
        # logging.debug( r)
        # only use rule_code load data
        if r[0].find(KVSEP)!=-1:
            rulecode = r[0].split(KVSEP)[0]
        else:
            rulecode = r[0]
        dimvlu = r[1]
        cnt = r[2]
        rnk = r[3]
        if rulecode is None or rulecode not in rdic:
            logging.error('not found rulecode: %s' , rulecode)
            continue
        new_row = [dt2int(dt)]
        new_row.extend(rdic[rulecode])
        if dimvlu.find(KVSEP) == -1:
            new_row.extend([dimvlu, '', cnt, rnk])
        else:
            dim1, dim2 = dimvlu.split(KVSEP, 1)
            new_row.extend([dim2, dim1, cnt, rnk])
        #rsql = f_sql % (",".join(map(sql_value_format, new_row)))
        #logging.debug( rsql)
        # print len(new_row),new_row
        rows.append(new_row)
    return f_sql, rows


def execute_to_mysql(conn, sql, rows):
    logging.info( rows[:5])
    logging.info('SQL\n%s', sql)
    cnt=conn.executemany(sql, rows)
    logging.warning('Replaced Cnt:%s, SQL:%s',cnt,sql)
    return rows

def dt2int(dt):
    return dt.replace('-','')

def delete_mysql_old(conn,tbls,dt,targets):
    for target in targets:
        hu=HiveUtil()
        s_tbls=set([hu.remove_prefix(tbl) for tbl in tbls])
        tbnames="','".join(s_tbls)
        data={'target':target,'dt':dt2int(dt),'tbnames':tbnames}
        sql="""Delete from {target} 
        where table_name in ('{tbnames}')
        and report_date={dt};""".format(**data)
        logging.warning('SQL\n%s', sql)
        cnt=conn.execute(sql)
        logging.warning('Deleted rows %s',cnt)


def load_table_hive_to_mysql(opts):
    if opts.source_table == '_':
        tbls = open(BASEDIR + '/conf/table_list').read().splitlines()
    else:
        tbls = opts.source_table.split(',')
    # all_table_level info
    hu = HiveUtil()
    dt = opts.date

    rules_cache = BASEDIR + '/data/rules_cache.json'
    exinfo_rule_field = load_json_cache(
        rules_cache, 'rule_code', 'database_name,table_name,field_name,field_id,rule_type,rule_sub_type,rule_id')
    exinfo_field_field = load_json_cache(rules_cache, 'database_name,table_name,field_name',
                                         'database_name,table_name,field_name,field_id,rule_type,rule_sub_type,rule_id')
    exinfo_table = load_json_cache(
        rules_cache, 'rule_code', 'database_name,table_name,table_id,rule_type,rule_id')
    exinfo_overview = load_json_cache(
        rules_cache, 'database_name,table_name', 'database_name,table_id,table_name')
    # for tb_name in ['ods.o_p04_app_client_data_i']:
    conn = DB_CONN(*MYSQL_CONF)
    # delete 
    targets=['monitor_field_rule_result_stat','monitor_table_rule_result_stat','monitor_table_record_stat_overview']
    delete_mysql_old(conn,tbls,dt,targets)
    for tb_name in tbls:
        stb_name = hu.remove_prefix(tb_name)
        logging.info( 'input parameter "source":%s'% stb_name)
        for type in ['field', 'field_overview', 'table']:
            type_fn = type
            if type == 'field_overview':
                type_fn = 'field'
            suffix = app_conf['projects'][type_fn]['suffix']
            tbn = '%s.%s_%s' % (db_prefix, stb_name, suffix)
            logging.info( 'Read result table:%s'% tbn)
            fname = BASEDIR + '/data/rst/%s/%s.%s.gz' % (type_fn, tbn, dt)
            ## export from hive
            if (not os.path.exists(fname)) or opts.force_update:
                std, err = hu.hive_call("select * from %s where dt='%s'" %
                                        (tbn, dt), fname)
            if type == 'field':
                sql, rows = load_field_stat(
                    exinfo_rule_field, exinfo_field_field, dt, fname, tb_name)
            elif type == 'table':
                sql, rows = load_table_stat(exinfo_table, dt, fname)
            elif type == 'field_overview':
                sql, rows = load_f_overview_stat(
                    exinfo_overview, dt, fname, tb_name)
            logging.debug( 'Process Type:%s Count:%s File:',type, len(rows),fname)
            for row in rows[:10]:
                logging.debug('[toMysql type:%s] %s',type,row)
            execute_to_mysql(conn, sql, rows)


if __name__ == '__main__':
    parser = OptionParser()
    dft_date = get_date(days=-1)
    parser.add_option("-d", "--date", dest="date",
                      default=dft_date, help='date to import')
    parser.add_option("-s", "--source", dest="source_table",
                      default='_', help='source_table split by ","')
    parser.add_option("-f", "--force", dest="force_update",
                      default=False,action='store_true', help='force update from hive')
    (opts, args) = parser.parse_args()
    #opts.date='2016-12-12'
    #opts.source_table='ods.o_p04_app_event_log_i'
    #opts.source_table='ods.o_p04_pv_log_i'
    load_table_hive_to_mysql(opts)
