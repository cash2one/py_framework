#!coding:utf8
# python syntax template

create_full_tp = '''\
use {layer};
-- drop table if exists {layer}.{0};
create  external table IF NOT EXISTS {layer}.{0}
(
{1}
)
comment '{2}'
PARTITIONED BY (
{3}
)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY '\\007' 
  -- LINES TERMINATED BY '\\n'
  COLLECTION ITEMS TERMINATED BY '\\002'
  MAP KEYS TERMINATED BY '\\003'
STORED AS RCFILE
LOCATION  '/warehouse/{layer}/{project}/{0}';
'''
create_f_stat_tp = '''\
use {layer};
-- drop table if exists {layer}.{0};
create external table IF NOT EXISTS {layer}.{0}
(
dim_type string,
dim_value string,
app_key string,
cnt string
)
comment ''
PARTITIONED BY (
dt string
)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY '\\007' 
  -- LINES TERMINATED BY '\\n'
  COLLECTION ITEMS TERMINATED BY '\\002'
  MAP KEYS TERMINATED BY '\\003'
STORED AS RCFILE
LOCATION  '/warehouse/{layer}/{project}/{0}';
'''
create_t_stat_tp = '''\
use {layer};
-- drop table if exists {layer}.{0};
create external table {layer}.{0}
(
rule_code string,
dim_value string,
cnt string,
rank string
)
comment ''
PARTITIONED BY (
dt string,
count_type string
)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY '\\007' 
  -- LINES TERMINATED BY '\\n'
  COLLECTION ITEMS TERMINATED BY '\\002'
  MAP KEYS TERMINATED BY '\\003'
STORED AS RCFILE
LOCATION  '/warehouse/{layer}/{project}/{0}';
'''
