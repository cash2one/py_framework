#!coding:utf8
import json
import sys
import os
import logging
from os.path import basename
from HiveUtil import HiveUtil
import dw_qa_util
from app_conf import app_conf, db_prefix, BASEDIR
try:
    import sqlparse
except:
    sqlparse = None

PYPY_EXEC = 'pypy5.6.tar.gz/bin/pypy'
PYPY_TAR_PATH = BASEDIR + '/lib/pypy5.6.tar.gz'


def gen_hql_add_files(files, is_archive=False):
    '''
    generate add statement
    '''
    st = ''
    for file in files:
        if is_archive:
            st += 'add archive %s;\n' % file
        else:
            st += 'add file %s;\n' % file
    return st


def format_files(dfiles, full=False):
    ret = []
    for dfile in dfiles:
        if full:
            ret.append(BASEDIR + '/data/dims/%s' % dfile)
        else:
            ret.append('%s' % dfile)
    return ret


def gen_hql_cols(*cols_s):
    sts = []
    for cols in cols_s:
        if len(cols) > 0:
            sts.append(', '.join(cols))
    st = '\n    ,'.join(sts)
    return st.strip(' ,')


def gen_cmd(script, jtype, rfile, mfile, dfiles):
    cmd = '{0} {1}  '.format(PYPY_EXEC, script)
    if jtype:
        cmd += ' -j "{0}" '.format(jtype)
    if rfile:
        cmd += ' -r "{0}" '.format(basename(rfile))
    if mfile:
        cmd += ' -m "{0}" '.format(basename(mfile))
    if dfiles and len(dfiles) > 0:
        cmd += ' -d {0} '.format(','.join(dfiles))
    return cmd


def get_col_names(jobj, keyname='col_name'):
    '''
    get column name
    '''
    cols = []
    for field in jobj:
        if type(field) == list:
            cols.append('`%s`' % field[0])
        else:
            cols.append('`%s`' % field[keyname])
    return cols


def get_col_names_with_exp(jobj):
    '''
    get column name with expression
    '''
    cols = []
    for key in sorted(jobj.keys()):
        express = jobj[key].replace('\r\n', '  ')
        sub = '(  ' + express + '  )  -- %s \n ' % key
        #sub='(  '+ express +'  )   '
        logging.debug(
            'explain select %s from ods.o_p04_app_client_data_i;' % sub)
        cols.append(sub)
        #cols.append('\n '+ express +' ')
    return cols


def generate_transform_hql_data(rule_file):
    '''
    input table_rules
    return the transform HQL
    '''
    table_rules = json.load(open(rule_file))
    trans_script = 'trans_mr.py'
    stat_script = 'stat_mr.py'
    hu = HiveUtil()
    source_table = hu.add_prefix(table_rules['table_name'])
    short_tb_name = hu.remove_prefix(source_table)

    tbl_conf = app_conf['projects']['error']
    prj_dir = tbl_conf['proj_dir']
    suffix = tbl_conf['suffix']
    #
    target_table = db_prefix + '.%s_%s' % (short_tb_name, suffix)    #
    #
    meta_file = BASEDIR + "/data/meta/%s.meta.json" % source_table
    table_meta = json.load(open(meta_file))
    #
    cols = get_col_names(table_meta['column_info'])
    pcols = get_col_names(table_meta['partition_info'])
    #
    dcols = get_col_names_with_exp(table_rules['derive_cols'])
    dfiles = table_rules['dim_files']
    # extra column in result table
    ecols = get_col_names(tbl_conf['info_col'])
    epcols = get_col_names(tbl_conf['part_col'])
    #
    data = {}
    # extra set clause for hql
    data['extra_set'] = ''
    # add files
    trans_files = [BASEDIR + '/py/' + trans_script]
    trans_files.append(BASEDIR + '/py/app_conf.py')
    trans_files.append(meta_file)
    trans_files.append(rule_file)
    dim_cache_files = format_files(dfiles, full=False)
    trans_files += format_files(dfiles, full=True)
    stat_files = [BASEDIR + '/py/' + stat_script, rule_file]
    data['trans_add_files'] = gen_hql_add_files(trans_files, is_archive=False)
    data['stat_add_files'] = gen_hql_add_files(stat_files, is_archive=False)
    data['add_archives'] = gen_hql_add_files([PYPY_TAR_PATH], is_archive=True)
    data['source_table'] = source_table
    data['input_cols'] = gen_hql_cols(cols, pcols, dcols)
    data['map_cmd'] = gen_cmd(
        trans_script, 'ods_mapper', rule_file, meta_file, dim_cache_files)
    data['stat_map_cmd'] = gen_cmd(
        stat_script, None, rule_file, None, None)
    data['map_output_keys'] = 'CLUSTER BY '
    data['map_output_keys'] = ' '
    data['map_output_cols'] = gen_hql_cols(ecols, cols, epcols, pcols)
    data['where_condition'] = "WHERE dt='${hivevar:dt}'"
    data['target_table'] = target_table
    # rs_pcols=['dt']
    rs_pcols = []
    data['target_partition'] = "dt='${hivevar:dt}'  "
    data['reduce_cmd'] = gen_cmd(
        trans_script, 'ods_reducer', rule_file, meta_file, dim_cache_files)
    data['reduce_output_cols'] = gen_hql_cols(ecols, cols, epcols, rs_pcols)
    return data


def apply_template(data, *hql_tps):
    ''' apply data dict to series template
        use format function
    '''
    hql = ''
    for hql_tp in hql_tps:
        hql += hql_tp.format(**data)
    logging.debug(hql)
    return hql


def gen_error_hql(tbname):
    from template import hql_prepare_tp, hql_error_transform_tp, hql_test_tp
    rule_file = BASEDIR + '/data/rule/%s.rule.json' % tbname
    data = generate_transform_hql_data(rule_file)
    hql = apply_template(data, hql_prepare_tp, hql_error_transform_tp)
    fname = BASEDIR + '/hql/%s.error.hql' % tbname
    fh = open(fname, 'w')
    fh.write(hql)
    return fname, hql


def gen_error_test_hql(tbname):
    from template import hql_prepare_tp, hql_error_transform_tp, hql_test_tp
    rule_file = BASEDIR + '/data/rule/%s.rule.json' % tbname
    data = generate_transform_hql_data(rule_file)
    # make test hql
    hql = apply_template(data, hql_prepare_tp, hql_test_tp)
    fname = BASEDIR + '/hql/test/%s.error.test.hql' % tbname
    fh = open(fname, 'w')
    fh.write(hql)
    logging.debug(hql)
    return fname, hql


def gen_local_test_sh(tbname):
    from template import local_test_sh_tp
    rule_file = BASEDIR + '/data/rule/%s.rule.json' % tbname
    data = generate_transform_hql_data(rule_file)
    data['basedir'] = BASEDIR
    data['head_count'] = 1000
    sh = apply_template(data, local_test_sh_tp)
    fname = BASEDIR + '/sh/test/%s.sh' % tbname
    sh = sh.replace('pypy5.6.tar.gz', 'pypy-5.6')
    open(fname, 'w').write(sh)
    return fname, sh


def gen_stat_hql(tbname):
    from template import hql_stat_tp
    tbl_conf = app_conf['projects']['field']
    prj_dir = tbl_conf['proj_dir']
    suffix = tbl_conf['suffix']

    rule_file = BASEDIR + '/data/rule/%s.rule.json' % tbname
    data = generate_transform_hql_data(rule_file)
    meta_file = BASEDIR + '/data/meta/%s.meta.json' % tbname
    mjo = json.load(open(meta_file))
    meta_cols = [field['col_name'] for field in mjo['column_info']]
    if 'app_key' in meta_cols:
        cols_setting = {'other_cols': 'app_key'}
    else:
        cols_setting = {'other_cols': "''"}

    hu = HiveUtil()
    fname = BASEDIR + '/hql/%s.stat.hql' % tbname
    fh = open(fname, 'w')
    short_tb_name = hu.remove_prefix(tbname)
    data.update(cols_setting)
    data .update({'source_table': db_prefix + '.' + short_tb_name + '_e',
                  'target_table': db_prefix + '.' + short_tb_name + '_f'})
    hql = apply_template(data, hql_stat_tp)
    logging.debug(hql)
    fh.write(hql)
    return fname, hql


def gen_group_dim_pair(col_obj):
    '''generate hql map column string
    '''
    parts = []
    for rule_code in col_obj:
        field_names = col_obj[rule_code]['field_names']
        field_name_str = "concat_ws('\\005',%s)" % (','.join(field_names))
        if len(field_names)>1:
            group_key = "concat_ws('\\005','%s',concat_ws('\\006',%s))" % (rule_code,','.join(field_names[:-1]))
        else:
            group_key = "'%s'"%rule_code
        part = "%s,  %s" % (group_key, field_name_str)
        parts.append(part)
    return '\n'+' \n, '.join(parts)


def get_tbl_lvl_hql(tbname):
    from template import hql_rank_tp_prep, hql_rank_tp_cnt
    tbl_conf = app_conf['projects']['table']
    prj_dir = tbl_conf['proj_dir']
    suffix = tbl_conf['suffix']
    hu = HiveUtil()
    short_tb_name = hu.remove_prefix(tbname)
    data = {'source_table': tbname,
            'target_table': db_prefix + '.' + short_tb_name + '_t'}
    hql = apply_template(data, hql_rank_tp_prep)
    rule_file = BASEDIR + '/data/rule/%s.rule.json' % tbname
    jdata = json.load(open(rule_file))
    chqls = []
    for count_type in jdata['table_level_rules']:
        count_obj = {'count_type': count_type}
        count_obj.update(data)
        col_obj = jdata['table_level_rules'][count_type]
        logging.debug(col_obj)
        count_obj['group_dim_pair'] = gen_group_dim_pair(col_obj)
        count_obj['rankmax'] = '1000'
        chql = apply_template(count_obj, hql_rank_tp_cnt)
        chqls.append(chql)
    hql += ' \n -- step split \n'.join(chqls)
    fname = BASEDIR + '/hql/%s.table_rule.hql' % tbname
    fh = open(fname, 'w')
    logging.debug(hql)
    fh.write(hql)
    return fname, hql


def gen_all_query_shell(tbname):
    fname_test_sh, sh = gen_local_test_sh(tbname)
    fname_test_hql, test_hql = gen_error_test_hql(tbname)
    #
    fname_base, hql = gen_error_hql(tbname)
    fname_stat, hql = gen_stat_hql(tbname)
    fname_tlr, hql = get_tbl_lvl_hql(tbname)
    from template import cmd_tp 
    table_cmd = cmd_tp.format(basedir=BASEDIR, tbname=tbname,
                              fname_base=fname_base, fname_stat=fname_stat,
                              fname_tlr=fname_tlr)
    logging.info('QM update[test shell]: %s' % fname_test_sh)
    logging.info('QM update[test hql  ]: %s' % fname_test_hql)
    logging.info('QM update[error layer hql]: %s' % fname_base)
    logging.info('QM update[stat layer hql ]: %s' % fname_stat)
    logging.info('QM update[table layer hql]: %s' % fname_tlr)
    # print table_cmd
    return table_cmd


def gen_tbl_shell(table_cmd, tb_name):
    from template import shell_tp
    dt = dw_qa_util.get_date()
    sh = shell_tp.format(user='qa', cmd=table_cmd, date=dt, tbname=tb_name)
    logging.debug(sh)
    fname = BASEDIR + '/sh/auto/%s.sh' % tb_name
    with open(fname, 'w') as fh:
        logging.info('QM update[ods_table shell]: %s' % fname)
        fh.write(sh)
    return fname


def main():
    tbls = open(BASEDIR + '/conf/table_list').read().splitlines()
    dt = dw_qa_util.get_date()
    cmd=""". ~/.bash_profile
    python {0}/py/dim_checker.py 
    python {0}/py/rule_manager.py -d -r -q
    ### refresh dim @ {1} 
    python {0}/py/query_manager.py  
    ### refresh query/shell @ {1} \n""".format(BASEDIR,dt)
    for tb_name in tbls:
        table_cmd = gen_all_query_shell(tb_name)
        # cmds+=cmd
        fname = gen_tbl_shell(table_cmd, tb_name)
        cmd+='sh %s\n'%fname
    cmd+='python {0}/py/message_manager.py \n### generate @ {1} '.format(BASEDIR,dt)
    logging.debug( '\n%s',cmd)
    #fout=open(BASEDIR+'/sh/auto/all_task.sh','w')
    #fout.write(cmd)

if __name__ == '__main__':
    main()
