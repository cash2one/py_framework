import json
import logging
from pprint import pprint
from app_conf import BASEDIR
import os
import re
# try:
#    import sqlparse
# except:
#    sqlparse=None
sqlparse = None


def normalize_query(query):
    query = query.lower()
    if sqlparse:
        query = sqlparse.format(query, reindent=True)
        query = query.replace('\n', ' ')
    else:
        query = query.replace('\n', ' ').strip()
        pat = re.compile('\s+')
        query = pat.sub(' ', query)
        pass
    return query


def find_target_dim(srcs):
    rule_codes = []
    for row in srcs:
        tbl, rule_code, old_fname = row
        if old_fname.find('.zip.') != -1:
            return old_fname.replace('.gz', '')
        rule_codes.append(rule_code)
    return min(rule_codes)


def get_reverse_index(jobj):
    all_dim_query = {}
    # from dim files collect all dim file info
    for tbl in jobj:
        tbobj = jobj[tbl]
        tmp_dc = {}
        # print tbobj.keys()
        for old_fname, obj in tbobj['dim_files'].items():
            rule_codes = obj['rule_codes']
            if obj['query'] is None:
                logging.error('Query is None: %s',rule_codes)
                continue
            for rule_code in rule_codes:
                tmp_dc[(tbl, rule_code, old_fname)
                       ] = normalize_query(obj['query'])
        all_dim_query.update(tmp_dc)
        # print tbobj['direct_rules']
    rev_idx = {}
    for key, query in all_dim_query.items():
        rev_idx.setdefault(query, {'cnt': 0, 'srcs': []})
        rev_idx[query]['cnt'] += 1
        rev_idx[query]['srcs'].append(key)
    # logging.debug(pprint(rev_idx))
    for key in rev_idx:
        this_row = rev_idx[key]
        tgt = find_target_dim(this_row['srcs'])
        rev_idx[key]['tgt'] = tgt
        logging.debug('Merge Dim File,\nQuery:[%s]\nFrom:%s To %s' % (
            key, [row[1] for row in rev_idx[key]['srcs']],  tgt))
    # check duplicate detail
    # pprint(rev_idx)
    json.dump(rev_idx, open(
        BASEDIR + '/data/rule/merge.mapping.json', 'w'), indent=2)

    # print merge result
    logging.info('[Merge Dim files from %s to %s] ' %
                 (len(all_dim_query), len(rev_idx)))
    return rev_idx


def merge_dims(jobj):
    # get reverse index ,index by query
    rev_idx = get_reverse_index(jobj)
    # modify the parsed rules
    for content in rev_idx.values():
        sources = content['srcs']
        target = content['tgt']
        ##
        for source in sources:
            tbl = source[0]
            rule_code = source[1]
            old_fname = source[2]
            # modify direct rule
            new_fname = old_fname.replace(rule_code, target)
            jobj[tbl]['direct_rules'][rule_code]['dim_file'] = new_fname
            # print target,new_fname
            # change the dim_files part in rule_json
            logging.debug('mapping %s %s ' % (old_fname, new_fname))
            if old_fname != new_fname:
                dinfo = jobj[tbl]['dim_files'][old_fname]
                old_rule_codes = jobj[tbl]['dim_files'][
                    old_fname]['rule_codes']
                if new_fname not in jobj[tbl]['dim_files']:
                    jobj[tbl]['dim_files'][new_fname] = dinfo
                else:
                    jobj[tbl]['dim_files'][new_fname][
                        'rule_codes'].extend(old_rule_codes)
                jobj[tbl]['dim_files'].pop(old_fname)
    # logging.debug(pprint(jobj))
    return jobj


def main():
    jobj = json.load(open(BASEDIR + '/data/rule/all.parsed.json'))
    merge_dims(jobj)

if __name__ == '__main__':
    main()
