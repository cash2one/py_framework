#!coding:utf8
import json
import logging
import pprint
import os
from dw_qa_util import DB_CONN
from app_conf import app_conf, db_prefix, BASEDIR, MYSQL_CONF
from HiveUtil import HiveUtil
from multiprocessing import Pool
from rule_manager import get_rules_from_db, is_field_name, getkeys


def check_rules(rules_view):
    # logging.debug( pprint.pprint(rules_view))
    parse_res = {}
    rule_types = set()
    for row in rules_view:
        table_name = '{0}.{1}'.format(row['database_name'], row['table_name'])
        parse_res.setdefault(table_name, {})
        tbl_obj = parse_res[table_name]
        tbl_obj['table_name'] = table_name
        rule_types.add(row['rule_type'])
        rule_type = row['rule_type']
        rule_sub_type = row['rule_sub_type']
        rule_code = row['rule_code']
        field_name = row['field_name']
        rule_expression_1 = row['rule_expression_1']
        rule_expression_2 = row['rule_expression_2']
        tbl_obj.setdefault('direct_rules', {})
        tbl_obj.setdefault('derive_cols', {})
        tbl_obj.setdefault('dim_files', {})
        status = max(int(row['rule_status']), int(
            row['field_status']), int(row['table_status']))
        is_valid = min(int(row['rule_is_valid']), int(row['field_is_valid']))
        ## not valid
        if (status != 1) or (is_valid != 1):
            info = 'not active rule: %s,%s' % (rule_code, getkeys(
                row, ['rule_status', 'field_status', 'table_status', 'rule_is_valid', 'field_is_valid']))
            # logging.warning(info)

        elif rule_type in [u'dim']:
            # logging.debug(pprint(row))
            dim_file = '%s.gz' % rule_code
            # hard code for user_id
            if rule_code.startswith('user_id'):
                dim_file = 'user_id.zip.gz'
            tbl_obj['dim_files'][dim_file] = {
                'query': rule_expression_1, 'rule_code': rule_code}
            # print dim_file
            # is direct field of table
            is_field_flg, expr = is_field_name(rule_expression_2)
            logging.debug('%s; %s' % (expr, is_field_flg))
            if is_field_flg:
                continue
            else:
                # TODO complex dim
                logging.debug('parse dim rule expr : %s' % expr)
                expr = 'concat(%s)' % expr.replace(';', ",'\t',")
                tbl_obj['derive_cols'][rule_code] = expr
        # enum type
        elif rule_type in [u'enum']:
            # logging.debug(pprint.pprint(row))
            sql = '''case when {0} in ({1}) then 'valid' 
                else {0} end
            '''
            tbl_obj['derive_cols'][rule_code] = sql.format(
                field_name, rule_expression_1)

        # custom type
        elif rule_type in [u'length', u'custom', u'reg', u'range']:
            # logging.debug(pprint.pprint(row))
            tbl_obj['derive_cols'][rule_code] = rule_expression_1

        # not handle rules
        # table rules pass
        elif rule_type in [u'dupt', u'topn']:
            #logging.warning('table level rule_type: %s' % row)
            pass
        # no rule_type
        elif rule_type is None:
            #logging.warning('rule_type is null: %s' % row)
            pass
        # other pass
        else:
            #logging.debug('not support rule_type : %s' % row)
            pass
    # logging.debug(pprint.pprint(parse_res) )
    return parse_res


def check_with_hive(hql_dc):
    hu = HiveUtil()
    sqls = ''
    for rc, sql in hql_dc.items():
        sqls += sql
    out, errout = hu.hive_call(sqls)
    return out.splitlines()[-1], out, errout


def check_one_dict_part(args):
    hql_dc, i = args[0], args[1]
    ret, out, errout = check_with_hive(hql_dc)
    if len(ret.strip()) == 0:
        logging.info('[Check Pass Test Group : No.%d]' % i)
        return True
    logging.error('[RAW ERROR SQL Group %s] %s' % (i, hql_dc[ret]))
    logging.error(out)
    return False


def main():
    conn = DB_CONN(*MYSQL_CONF)
    # dump rules to json cache
    get_rules_from_db(conn)
    res = json.load(open(BASEDIR + '/data/rules_cache.json'))
    tables_conf = check_rules(res)
    hql_dc = {}
    hql_tb = {}
    for tbname in tables_conf:
        # derive_cols
        cols = tables_conf[tbname]['derive_cols']
        for rule_code in cols:
            sql = '''
            select '{2}';
            explain select {1} from {0} limit 10;
            '''
            # print hql
            logging.debug('%s %s %s' % (tbname, rule_code, cols[rule_code]))
            hql = sql.format(tbname, cols[rule_code], rule_code)
            # hql_tb.setdefault(tbname,{})
            #hql_tb[tbname].setdefault(rule_code, [])
            if rule_code.find('-dim-') == -1 and (hql.find('vaild') != -1 or hql.find('valid') == -1):
                logging.warning(rule_code)
                logging.warning(hql)
            hql_dc[rule_code] = hql
        # dim file query
        dfs = tables_conf[tbname]['dim_files']
        for df_obj in dfs:
            query = dfs[df_obj]['query']
            key = rule_code + '|dim_query'
            hql_dc[key] = "select '%s';\nexplain %s;" % (key, query)
        # format hql
        for key, hql in hql_dc.items():
            hql = hql.replace('\r', '  ').replace('\n', '  ')
            hql_dc[key] = hql
    #hql_dc={'aa':'sselect 11'}
    logging.debug(json.dumps(hql_dc, indent=2))
    split_test(hql_dc)


def split_test(hql_dc, group=9):
    d = hql_dc
    lt = len(d)
    sp_grp = [i for i in range(0, lt, lt / group)]
    sp_grp.append(lt)
    logging.info('[Test Group Total:%s, Groups: %s]' % (lt, sp_grp))
    p = Pool()
    arg_arr = []
    for i, idx in enumerate(sp_grp[:-1]):
        test_hqls = dict(d.items()[idx:sp_grp[i + 1]])
        # print idx,sp_grp[i+1]
        arg_arr.append([test_hqls, i])
    p.map(check_one_dict_part, arg_arr)


if __name__ == '__main__':
    main()
