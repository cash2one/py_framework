import sys
import os
import json
from optparse import OptionParser


def str2dic(st, arrsep='\002', kvsep='\003'):
    ''' string 2 dict
    '''
    r_dic = {}
    for kv in st.split(arrsep):
        res = kv.split(kvsep, 1)
        if len(res) > 1:
            k, v = res
        else:
            k, v = res[0], ''
        r_dic[k] = v
    return r_dic


def get_slice(rule_code, idx):
    arr = rule_code.split('-')
    if idx < len(arr):
        return arr[idx]
    else:
        return ''


def load_json(fname):
    ishadoop = os.environ.get("mapreduce_job_id", False)
    if fname.endswith('must_set.json'):
        return {}
    if not ishadoop:
        type = fname.split('.')[-2]
        fname = BASEDIR + '/data/%s/' % type + fname
    return json.load(open(fname))


def get_importance(rules_importance, rule):
    for key in rules_importance:
        if rule in rules_importance[key]:
            return key
    return 'not_set'


def stat_mapper(opts):
    counter = {}
    rules = load_json(opts.rule)
    rules_importance = rules.get('importance', {})
    for l in sys.stdin:
        rs = {}
        r = l.strip('\n').split('\t')
        mp = str2dic(r[0])
        # special sum type for valid data
        if mp.get('tag_type', '') == 'datasum':
            for app_key, cnt in mp.items():
                if app_key == 'tag_type':
                    continue
                row = ['valid', app_key]
                row.extend(r[1:])
                row.append(cnt)
                key = '\t'.join(row)
                print '\t'.join([key, str(cnt)])
        rs['rule'] = mp.keys()
        rules = mp.keys()
        rs['field'] = set([get_slice(rule, 0) for rule in rules])
        rs['dim'] = set([get_slice(rule, 2) for rule in rules])
        rs['importance'] = set(
            [get_importance(rules_importance, rule) for rule in rules])
        if 'not_set' in rs['importance']:
            rs['importance'].remove('not_set')
        for type in ['rule', 'field', 'dim', 'importance']:
            for value in rs[type]:
                row = [type, value]
                row.extend(r[1:])
                key = '\t'.join(row)
                counter.setdefault(key, 0)
                counter[key] += 1
    for key, vlu in counter.items():
        print '\t'.join([key, str(vlu)])

if __name__ == '__main__':
    argv = sys.argv
    parser = OptionParser()
    parser.add_option("-r", "--rule", dest="rule", default='rule_must_set.json',
                      help="rule info json file", metavar="FILE")
    (opts, args) = parser.parse_args()
    stat_mapper(opts)
