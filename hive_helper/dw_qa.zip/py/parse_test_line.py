import json
from optparse import OptionParser
from app_conf import BASEDIR
tbname='ods.o_p04_app_event_log_i'
tbname='ods.o_p04_pv_log_i'

parser=OptionParser()
parser.add_option("-q",  dest="query",default='*')
parser.add_option("-s",  dest="source",default=tbname)
parser.add_option("-t",  dest="tail",default=100)
parser.add_option("-l",  dest="layer",default='ods')
(opts, args) = parser.parse_args()

query=opts.query
tbname=opts.source

jo=json.load(open(BASEDIR+'/test/meta.%s.json'%tbname))
if opts.layer=='ods':
    fin=open(BASEDIR+'/test/ods/%s.dump.log'%tbname)
elif opts.layer=='map':
    jo.insert(0,'invalid_rule_tag')
    fin=open(BASEDIR+'/test/map/%s.map.out'%tbname)
elif opts.layer=='reduce':
    jo.insert(0,'invalid_rule_tag')
    fin=open(BASEDIR+'/test/reduce/%s.reduce.out'%tbname)
jo=map(str,jo)
opts.tail=int(opts.tail)
print 'column: ',jo

def str2map(st,sep1='\002',sep2='\003'):
    arr=st.split(sep1)
    dc={}
    for pair in arr:
        parr=pair.split(sep2)
        dc[parr[0]]=parr[1]
    return dc

def select_keys(dc,query):
    keys=query.split(',')
    rd={}
    dc=dict(dc)
    for k in keys:
        if k=='invalid_rule_tag':
            rd[k]=str2map(dc.get(k,'notfound'))
        else:
            rd[k]=dc.get(k,'notfound')
    return rd

for i,line in enumerate(fin):
    row = line.strip().split('\001')
    rd= zip(jo,row)
    if i >opts.tail:
        break
    if query!='*': 
        print select_keys(rd,query)
    else:
        print rd
