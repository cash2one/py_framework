 mysql -h dp-mw0-3306-db.lq.autohome.com.cn -uzhineng -pkisWSlsoe392wsli  -Ddw_qa 
