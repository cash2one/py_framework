#!/bin/sh
###################################################################
#####################   并发运行 ##################################
###################################################################
echo $(dirname $0)/dt_run.n.sh \"sh xxx.sh\"  20160101 20160102  f 3
echo  "(f正向 b逆向 3并发度)"
start=$(date -d '1 days ago' +%Y%m%d)
end=$(date -d '0 days ago' +%Y%m%d)
cmd=${1:-"echo "}
start=${2:-$start}
end=${3:-$end}
order=${4:-"f"} #顺序
step=${5:-"1"}  #并发度
count=${6:-"365"}  #最大天数
#set -x
if [ $order = "f" ]; then
    echo forward
    dt=$start
    for (( i =0 ; i<$count ; i+=$step ))
    do
        for (( j=$i ; j<$(($i+$step)) && j <$count && dt<$end ;j++))
        do
            dt=$( date -d"$start $j days " +%Y%m%d ) 
            fdt=$( date -d"$start $j days " +%F ) 
            (    $cmd $fdt   
            ) &
        done
      wait
    done

else
    echo backward
    dt=$end
    for (( i =0 ; i<$count ; i+=$step ))
    do
        for (( j=$i ; j<$(($i+$step)) && j <$count && dt>$start ;j++))
        do
            dt=$( date -d"$end $j days ago" +%Y%m%d ) 
            fdt=$( date -d"$end $j days ago" +%F ) 
            (    $cmd $fdt
                ) &
        done
      wait
    done
fi

