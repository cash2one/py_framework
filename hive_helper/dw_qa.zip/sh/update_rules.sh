#!/bin/sh
basedir=$(dirname $0)
echo $basedir
cd $basedir/../py
python rule_manager.py
python query_manager.py
