mkdir -p sh py lib hql data create_table conf
mkdir -p data/meta data/dims data/rules 
mkdir -p data/rst/field data/rst/table
mkdir -p sh/auto sh/test
